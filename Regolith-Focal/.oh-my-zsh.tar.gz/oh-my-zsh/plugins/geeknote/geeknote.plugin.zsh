#Alias
alias gn='geeknote'
